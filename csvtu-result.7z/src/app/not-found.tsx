const NotFoundPage = () => {
    return ( 
        <h1>eat five start do nothing <span className="uppercase text-red-400 font-semibold">Not found</span></h1>
     );
}
 
export default NotFoundPage;