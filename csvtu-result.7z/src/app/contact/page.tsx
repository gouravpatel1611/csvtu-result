import ErrorCompPage from "@/components/ErrorComp";

const ContactPage = () => {
    return (
        <ErrorCompPage />
    );
}

export default ContactPage;