import ErrorCompPage from "@/components/ErrorComp";

const AboutPage = () => {
    return ( 
       <ErrorCompPage />
     );
}
 
export default AboutPage;